from __future__ import annotations

import os
import threading
from typing import Any, Optional

from xenevis.signals.signal import Signal
from xenevis.telegram.polling import TelegramPollingRunner


_PATCH_INSTALLED = False
TRACE_DELETE_AFTER_KEY = "telegram_delete_after_seconds"


def delete_after_seconds_from_env() -> int:
    raw = os.getenv("DELETE_TRANSLATIONS_AFTER_SECONDS", "120").strip()

    try:
        value = int(raw)
    except ValueError:
        return 120

    # 0 disables deletion. Negative values also disable it.
    return max(0, value)


def mark_translation_for_auto_delete(ctx, *, seconds: Optional[int] = None) -> None:
    trace = getattr(ctx, "trace", None)
    metadata = getattr(trace, "metadata", None)

    if not isinstance(metadata, dict):
        return

    resolved = delete_after_seconds_from_env() if seconds is None else max(0, int(seconds))

    if resolved <= 0:
        return

    metadata[TRACE_DELETE_AFTER_KEY] = resolved


def install_auto_delete_patch() -> None:
    """Patch Telegram polling to delete delivered translation messages later.

    The handler cannot know the message_id of a just-sent Telegram response.
    Telegram returns that ID only after sendMessage/editMessageText delivery.
    This bot-local patch captures that result on the Telegram surface edge and
    schedules deleteMessage after DELETE_TRANSLATIONS_AFTER_SECONDS.

    This should become a proper SDK surface feature later, for example:
        xenevis.telegram.reply_to(..., delete_after=120)
    """

    global _PATCH_INSTALLED

    if _PATCH_INSTALLED:
        return

    _PATCH_INSTALLED = True

    async def handle_update(self: TelegramPollingRunner, update: dict) -> None:
        update_id = update.get("update_id")

        if isinstance(update_id, int):
            self._offset = update_id + 1

        self._emit(
            "adapter.event.received",
            status="received",
            data={"adapter": "telegram", "update_id": update_id},
        )

        event = self.normalizer.normalize(update)

        if event is None:
            self._emit(
                "adapter.event.ignored",
                status="ignored",
                data={"adapter": "telegram", "update_id": update_id},
            )
            return

        self._emit(
            "adapter.event.normalized",
            status="normalized",
            data={
                "adapter": "telegram",
                "update_id": update_id,
                "event_type": getattr(event, "type", None),
                "action": getattr(event, "action", None),
            },
        )

        trace = await self.app.execute_event(event)
        output = trace.metadata.get("output")
        rendered = self.renderer.render(output)

        if rendered is None:
            self._emit(
                "telegram.output.skipped",
                status="skipped",
                data={"reason": "no_renderable_output", "trace_id": trace.id},
            )
            return

        chat_id = self._chat_id_from_event(event)

        if chat_id is None:
            self._emit(
                "telegram.output.skipped",
                status="skipped",
                data={"reason": "missing_chat_id", "trace_id": trace.id},
            )
            return

        method = rendered.get("method")

        self._emit(
            "telegram.output.created",
            status="created",
            trace_id=trace.id,
            data={"target": chat_id, "method": method},
        )

        message_id = event.payload.get("message_id") if isinstance(event.payload, dict) else None
        delivery = self.transport.deliver(rendered, chat_id=chat_id, message_id=message_id)

        self._emit(
            "telegram.output.delivered",
            status="delivered",
            trace_id=trace.id,
            data={"target": chat_id, "method": method},
        )

        delete_after = _trace_delete_after_seconds(trace)

        if delete_after > 0:
            delivered_message_id = _delivered_message_id(
                delivery=delivery,
                rendered=rendered,
                fallback_message_id=message_id if method == "editMessageText" else None,
            )

            if delivered_message_id is not None:
                _schedule_delete(
                    runner=self,
                    trace_id=trace.id,
                    chat_id=chat_id,
                    message_id=delivered_message_id,
                    delay_seconds=delete_after,
                )
            else:
                self._emit(
                    "telegram.delete.scheduled_skipped",
                    status="skipped",
                    trace_id=trace.id,
                    data={
                        "reason": "missing_delivered_message_id",
                        "target": chat_id,
                        "method": method,
                        "delete_after_seconds": delete_after,
                    },
                )

        callback_query_id = event.metadata.get("callback_query_id")
        if callback_query_id:
            self.transport.answer_callback_query(str(callback_query_id))
            self._emit(
                "telegram.callback.answered",
                status="delivered",
                trace_id=trace.id,
            )

    TelegramPollingRunner.handle_update = handle_update  # type: ignore[method-assign]


def _trace_delete_after_seconds(trace: Any) -> int:
    metadata = getattr(trace, "metadata", None)

    if not isinstance(metadata, dict):
        return 0

    value = metadata.get(TRACE_DELETE_AFTER_KEY)

    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _delivered_message_id(
    *,
    delivery: Any,
    rendered: dict[str, Any],
    fallback_message_id: Any = None,
) -> Any:
    if isinstance(delivery, dict):
        result = delivery.get("result")

        if isinstance(result, dict):
            message_id = result.get("message_id")
            if message_id is not None:
                return message_id

    params = rendered.get("params") if isinstance(rendered, dict) else None

    if isinstance(params, dict) and params.get("message_id") is not None:
        return params.get("message_id")

    return fallback_message_id


def _schedule_delete(
    *,
    runner: TelegramPollingRunner,
    trace_id: str,
    chat_id: str | int,
    message_id: Any,
    delay_seconds: int,
) -> None:
    runner._emit(
        "telegram.delete.scheduled",
        status="scheduled",
        trace_id=trace_id,
        data={
            "target": chat_id,
            "message_id": message_id,
            "delete_after_seconds": delay_seconds,
        },
    )

    def delete_later() -> None:
        try:
            runner.transport.call(
                "deleteMessage",
                {
                    "chat_id": chat_id,
                    "message_id": message_id,
                },
            )
        except Exception as exc:
            runner._emit(
                "telegram.delete.failed",
                status="failed",
                trace_id=trace_id,
                data={
                    "target": chat_id,
                    "message_id": message_id,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
            )
            return

        runner._emit(
            "telegram.delete.completed",
            status="completed",
            trace_id=trace_id,
            data={
                "target": chat_id,
                "message_id": message_id,
            },
        )

    timer = threading.Timer(delay_seconds, delete_later)
    timer.daemon = True
    timer.start()
