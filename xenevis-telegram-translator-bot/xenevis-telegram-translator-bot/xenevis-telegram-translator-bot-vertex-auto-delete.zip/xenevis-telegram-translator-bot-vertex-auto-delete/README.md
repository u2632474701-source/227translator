# Xenevis Telegram Translator Bot — Vertex AI + auto-delete

Ta wersja tłumaczy przez Vertex AI i automatycznie usuwa udane tłumaczenia po czasie.

Domyślnie:

```env
DELETE_TRANSLATIONS_AFTER_SECONDS=120
```

czyli 2 minuty.

## Flow

1. User odpowiada `/tr` na wiadomość.
2. Bot tłumaczy przez Vertex AI.
3. Bot odpowiada pod tłumaczoną wiadomością.
4. Po 2 minutach bot usuwa swoją wiadomość z tłumaczeniem.

## Dlaczego jest bot-local patch?

Handler Xenevis nie zna `message_id` wiadomości, którą bot dopiero wyśle. `message_id` wraca dopiero z Telegram API po `sendMessage` albo `editMessageText`.

Dlatego ta wersja dodaje mały patch na warstwie Telegram surface delivery:

- łapie odpowiedź Telegrama po `sendMessage`,
- wyciąga `result.message_id`,
- uruchamia `deleteMessage` po `DELETE_TRANSLATIONS_AFTER_SECONDS`.

Docelowo to powinno być w SDK jako normalne API:

```python
xenevis.telegram.reply_to(message_id, text, delete_after=120)
```

albo:

```python
xenevis.telegram.delete_after(120, output)
```

## `.env`

```env
TELEGRAM_BOT_TOKEN=...

GOOGLE_SHEET_ID=...
GOOGLE_SERVICE_ACCOUNT_FILE=service-account.json

GOOGLE_CLOUD_PROJECT=
GOOGLE_CLOUD_LOCATION=global
VERTEX_MODEL=gemini-2.5-flash
VERTEX_TIMEOUT_SECONDS=30

DELETE_TRANSLATIONS_AFTER_SECONDS=120
```

`DELETE_TRANSLATIONS_AFTER_SECONDS=0` wyłącza auto-usuwanie.

## Instalacja

```bat
py -m pip install -r requirements.txt
```

## Uruchomienie

```bat
py main.py
```

## Logi

Po wysłaniu tłumaczenia powinieneś zobaczyć sygnał:

```text
telegram.delete.scheduled
```

Po upływie czasu:

```text
telegram.delete.completed
```

Jeżeli bot nie ma uprawnień do usunięcia wiadomości, zobaczysz:

```text
telegram.delete.failed
```
